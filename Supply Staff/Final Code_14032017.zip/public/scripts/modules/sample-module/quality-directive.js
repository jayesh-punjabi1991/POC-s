define(['angular', './sample-module'], function (angular, directives) {
    'use strict';

directives.directive('iconQuality', function() {
  return {
    restrict: 'E',
    scope: {
      customerInfo: '=info'
    },
    templateUrl: 'views/quality_template.html'
  };
})
});

    
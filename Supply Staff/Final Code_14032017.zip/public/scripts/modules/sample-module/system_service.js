define(['angular', './sample-module'], function (angular, module) {
'use strict';

module.factory('SystemService', ['$http', '$q', function($http, $q){

    //var PARENT_URL='https://aviation-scd-srvc.run.aws-usw02-pr.ice.predix.io'
    var PARENT_URL='https://supplychainlocal.run.aws-usw02-pr.ice.predix.io'
    //var PARENT_URL='http://localhost:5094'
    var REST_SERVICE_URI = PARENT_URL+'/system/data/';
    var REST_SERVICE_POST_URI = PARENT_URL+'/system/create/';
    var REST_SERVICE_PUT_DELETE_URI = PARENT_URL+'/system/';
    var REST_SERVICE_UPLOAD_URI = PARENT_URL+'/upload/values';


    var factory = {
        fetchAllSystems: fetchAllSystems,
        createSystem: createSystem,
        updateSystem:updateSystem,
        deleteSystem:deleteSystem,
        uploadSystem:uploadSystem
    };

    return factory;

    function fetchAllSystems() {
        var deferred = $q.defer();
        console.log("-------SYSTEM SERVICE fetchAllSystems-------------")
        $http.get(REST_SERVICE_URI)
            .then(
            function (response) {
                console.log("response.data"+response.data);
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Systems:'+errResponse);
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function createSystem(system) {
        var deferred = $q.defer();
        $http.post(REST_SERVICE_POST_URI, system)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating System');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

     function uploadSystem(system) {
        console.log(system)
        var deferred = $q.defer();
        $http.post(REST_SERVICE_UPLOAD_URI, system)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating System');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }
    function updateSystem(system, id) {
        var deferred = $q.defer();
        $http.put(REST_SERVICE_PUT_DELETE_URI+id, system)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while updating System');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function deleteSystem(id) {
        var deferred = $q.defer();
        $http.delete(REST_SERVICE_PUT_DELETE_URI+id)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while deleting System');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

}]);
    });

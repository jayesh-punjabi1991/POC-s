define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('EnginePageCtrl', ['$scope', '$log', '$http', function ($scope, $log, $http) {
        $scope.clr = ["green", "red", "yellow"];
        $scope.selWeek='W4';
        $scope.loadWeek=function(){
          //var url='https://aviation-scd-srvc.run.aws-usw02-pr.ice.predix.io/engine/final?week='+$scope.selWeek;
          var url='https://supplychainlocal.run.aws-usw02-pr.ice.predix.io/engine/final?week='+$scope.selWeek;
          console.log(url)
          $http.get("dumbjson/engine.json").then(function(response){
            $scope.sysData=response.data
            $scope.rowData=$scope.sysData[0].rows;
          });
        }
        $scope.loadWeek()

        $scope.setHealth=function(clr, k){
            return "hcircle "+clr;
        };
        $scope.setTruckHealth=function(clr){
            return "flex-item__truck "+clr;
        }
        $scope.switchColor = function(clr, k, v, s) {
          var index = $scope.clr.indexOf(clr);
          if (index === 2) {
            index = -1;
          }
          $scope.rowData[k].quality[v]=$scope.clr[index + 1];
        }

        $scope.saveData=function(){
            //$http.post('https://aviation-scd-srvc.run.aws-usw02-pr.ice.predix.io/engine2/values2', $scope.sysData[0])
            $http.post('https://supplychainlocal.run.aws-usw02-pr.ice.predix.io/engine2/values2', $scope.sysData[0])
            .then(
            function (response) {
                console.log(response.data);
            },
            function(errResponse){
                console.error('Error while creating System');
            }
        )
          };

        $scope.switchTruck=function(clr, k, v, s){
          var index = $scope.clr.indexOf(clr);
          if (index === 2) {
            index = -1;
          }
          $scope.rowData[k][s].truck[v]=$scope.clr[index + 1];
        }

    }]);
});

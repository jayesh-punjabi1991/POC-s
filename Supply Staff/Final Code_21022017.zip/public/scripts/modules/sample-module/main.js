define(['./sample-module', './sample-directive', './sample-filter', './sample-service', './dashboard-controller', './blankpage-controller','./enginepage-controller',
    './sample-controller','./system_controller','./engine_controller','./engine_service','./system_service', './reportpage-controller','./predix-asset-service', './predix-user-service', './predix-view-service', './filechange', './csvarray'], function() {

});

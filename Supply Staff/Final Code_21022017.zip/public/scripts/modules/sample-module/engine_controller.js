define(['angular', './sample-module'], function (angular, controllers) {
'use strict';
 
/*angular.module('myApp').controller('SystemController', ['$scope', 'SystemService', function($scope, SystemService) {*/
    controllers.controller('EngineController', ['$scope', '$filter', 'EngineService', function($scope, $filter, EngineService) {
    var self = this;

    self.system={id:'',overallHealth:'',qualityVoc:'',deliveryVoc:'',quarterRate:'',act:'',otd:'',span:'',quarterRatePro:'',actPro:'',otdPro:'',spanPro:'',systemName:'',weekNo:''};
    self.systems=[];
 
    self.submit = submit;
    self.edit = edit;
    self.remove = remove;
    self.reset = reset;
     self.handler = handler;   
    self.MyFiles=[];
 
    fetchAllSystems();
     function handler(e,files){
        var reader=new FileReader();
        reader.onload=function(e){
            var string=reader.result;
            console.log(JSON.stringify($filter('csvToArray')(string)))
            //do what you want with obj !
        }
        reader.readAsText(files[0]);
    }
    function handler(e,files){
        var reader=new FileReader();
        reader.onload=function(e){
            var string=reader.result;
           //console.log(JSON.parse(JSON.stringify($filter('csvToArray')(string))))
        var objd={"a":$filter('csvToArray')(string)}
        EngineService.uploadSystem(objd)
            .then(
            fetchAllSystems,
            function(errResponse){
                console.error('Error while creating Systems');
            }
        );

            //do what you want with obj !
        }
        reader.readAsText(files[0]);
    }        
        
    function fetchAllSystems(){
        console.log("-------SYSTEM CONTROLLER fetchAllSystems-------------");
        EngineService.fetchAllSystems()
            .then(
            function(d) {
                console.log(d)
                self.systems = d;
            },
            function(errResponse){
                console.error('Error while fetching fetchAllSystems');
            }
        );
    }
 
    function createSystem(system){
         console.log("-------SYSTEM CONTROLLER ADD NEW-------------");
        EngineService.createSystem(system)
            .then(
            fetchAllSystems,
            function(errResponse){
                console.error('Error while creating Systems');
            }
        );
    }
 
    function updateSystem(system, id){
         console.log("-------SYSTEM CONTROLLER UPDATE EXISTING-------------");
        EngineService.updateSystem(system, id)
            .then(
            fetchAllSystems,
            function(errResponse){
                console.error('Error while updating Systems');
            }
        );
    }
 
    function deleteSystem(id){
         console.log("-------SYSTEM CONTROLLER DELETE -------------");
        EngineService.deleteSystem(id)
            .then(
            fetchAllSystems,
            function(errResponse){
                console.error('Error while deleting System');
            }
        );
    }
 
    function submit() {
       
        if( (self.system.id===null) || (self.system.id=='') ){
            console.log("-------SYSTEM CONTROLLER NEW SUBMIT  -------------");
            console.log('Saving New User', self.system);
            createSystem(self.system);
        }else{
            console.log("-------SYSTEM CONTROLLER UPDATE SUBMIT -------------");
            updateSystem(self.system, self.system.id);
            console.log('User updated with id ', self.system.id);
        }
        reset();
    }
 
    function edit(id){
        console.log('EDIT SYSTEM CONTROLLER id to be edited', id);
        for(var i = 0; i < self.systems.length; i++){
            if(self.systems[i].id === id) {
                self.system = angular.copy(self.systems[i]);
                break;
            }
        }
    }
 
    function remove(id){
        console.log("-------SYSTEM CONTROLLER REMOVE -------------");
        console.log('id to be deleted', id);
        if(self.system.id === id) {
            reset();
        }
        deleteSystem(id);
    }
 
 
    function reset(){
        console.log("-------SYSTEM CONTROLLER RESET -------------");
        self.system={id:'',overallHealth:'',qualityVoc:'',deliveryVoc:'',quarterRate:'',act:'',otd:'',span:'',systemName:'',weekNo:''};

    }
 
}]);
    });



define(['angular', './sample-module'], function (angular, module) {
'use strict';
 
module.factory('XLSXReaderService', ['$rootScope', '$q', function($rootScope, $q){
 
    var factory = {
        readFile: readFile
    };
 
    return factory;
 
    function readFile(file, showPreview) {
        var deferred = $q.defer();
        XLSXReader(file, showPreview, function(data){
            $rootScope.$apply(function() {
                console.log(data)
                deferred.resolve(data);
            });
        });

        return deferred.promise;
    }
 
    

 
}]);
    });
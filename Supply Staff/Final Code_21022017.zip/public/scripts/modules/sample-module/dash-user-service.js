define(['angular', './sample-module'], function(angular, module) {
    'use strict';

    /**
     * DashUserService 
     */
    module.factory('DashUserService', ['$q', '$http', function($q, $http) {

        var factory = {
            loadWeekData:loadWeekData,
            fetchWeekData: fetchWeekData
        };
     
        return factory;
     
        function loadWeekData() {
            var deferred = $q.defer();
            $http.get("dumbjson/view.json")
                .then(
                function (response) {
                    console.log("response.data"+response.data);
                    deferred.resolve(response.data);
                },
                function(errResponse){
                    console.error('Error while fetching Systems:'+errResponse);
                    deferred.reject(errResponse);
                }
            );
            return deferred.promise;
        }
        function fetchWeekData(){
            var o={}
                this.loadWeekData().then(
                    function(d) {
                        console.log(d)
                        o = d;
                    },
                    function(errResponse){
                        console.error('Error while fetching fetchAllSystems');
                    }
                );
            return o;
        }
    }]);
});

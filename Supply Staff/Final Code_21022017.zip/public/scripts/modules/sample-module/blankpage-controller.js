define(['angular', './sample-module'], function(angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('BlankPageCtrl', ['$scope', '$log', '$http', '$state', '$filter', function($scope, $log, $http, $state, $filter) {
        $scope.clr = [ "white1", "green", "red", "yellow" ];
        $scope.showcontainer = false;
        $scope.currentClr = $scope.clr[0]
        $scope.btnClr = "layout__item u-1/2 boxed health__" + $scope.currentClr;

        $scope.fn = ""

        /* Print Function */
        $scope.Print=function() {
        window.print();
        }
            /* LOAD JSON */
        $scope.checkHost = function() {
            //var url='https://aviation-scd-srvc.run.aws-usw02-pr.ice.predix.io/'+$state.current.name+'/final?week='+$scope.selWeek;
            var url = 'https://supplychainlocal.run.aws-usw02-pr.ice.predix.io/' + $state.current.name + '/final?week=' + $scope.selWeek;
            if (window.location.port === "9000") {
                url = "dumbjson/" + $state.current.name + ".json"
            }
            return url;
        }

        $scope.currentWeek = function() {
            Date.prototype.getWeek = function() {
                var onejan = new Date(this.getFullYear(), 0, 1);
                return Math.ceil((((this - onejan) / 86400000) + onejan.getDay() + 1) / 7);
            }

            return (new Date()).getWeek();
        }
        $scope.loadWeek = function() {



            $scope.showcontainer = false;
            $http.get($scope.checkHost()).then(function(response) {
                $scope.sysData = response.data
                $scope.rowData = $scope.sysData[0].rows;
                $scope.resetData($scope.rowData)
                $scope.showcontainer = true;

                $scope.options = {
                    elements: {
                        line: {
                            tension: 0,
                            fill: false,
                            borderWidth: 3,
                            borderColor: 'rgba(137,110,239,1)'
                        },
                        point: {
                            radius: 0
                        }
                    },
                    scaleShowGridLines: false,
                    pointDot: false,
                    bezierCurve: false,
                    scales: {
                        xAxes: [{
                            display: true,
                            gridLines: {
                                color: "rgba(0, 0, 0, 0)",

                                zeroLineColor: "rgba(255,255,255,0.5)"

                            },
                            ticks: {
                                display: false
                            },
                            scaleLineColor: "rgba(0, 0, 0, 0)"
                        }],
                        yAxes: [{
                            id: 'y-axis-1',
                            type: 'linear',
                            ticks: {
                                display: false,
                            },
                            display: true,
                            position: 'left',
                            gridLines: {
                                color: "rgba(0, 0, 0, 0)",
                                zeroLineColor: "rgba(255,255,255,0.5)"
                            }
                        }],
                    },
                    scaleShowLabels: false,
                    scaleLineColor: "rgba(0, 0, 0, 0)"
                }
                $scope.colours = [];
                $scope.labels = ["", "", "", ""];
                $scope.series = [''];
                $scope.data = [20, 30, 40, 10]


                //$scope.drawCharts()
            });
        }



        $scope.selWeek = "W" + $scope.currentWeek();
        $scope.loadWeek();

        //---------


        //---------

        $scope.resetData = function(a) {
            for (var i = 0; i < a.length; i++) {
                $scope.rowData[i].kpi.otd = $scope.redrawData(a[i].kpi.otd)
                $scope.rowData[i].kpi.sp = $scope.redrawData(a[i].kpi.sp)
                if ($scope.rowData[i].prokpi != undefined) {
                    $scope.rowData[i].prokpi.otd = $scope.redrawData(a[i].prokpi.otd)
                    $scope.rowData[i].prokpi.sp = $scope.redrawData(a[i].prokpi.sp)
                }

            }
        }
        $scope.checkMax = function() {

        }
        $scope.redrawData = function(a) {
            var x = [];
            for (var i = 0; i < a.length; i++) {
                for (var k = 0; k < a[i].length; k++) {
                    if (k === 1) {
                        x.push(a[i][k])
                    }
                }
            }
            return x
        }
        $scope.setHealth = function(clr, k) {
            return "hcircle " + clr.toLowerCase();
        };
        $scope.setCubeColors = function(index) {
            var clr = ""
            if ($scope.sysData != undefined) {
                clr = $scope.sysData[0].cross[index].toLowerCase()
            }
            return "flex-item__cubed " + clr
        };
        $scope.setTruckHealth = function(clr) {
            return "flex-item__truck " + clr.toLowerCase();
        }
        $scope.setPieColor = function(i, k) {
            return $scope.rowData[k].kpi.pie[i].toLowerCase();
        };
        $scope.switchCubeColor = function(k) {
            var currentClr = $scope.sysData[0].cross[k]
            var index = $scope.clr.indexOf(currentClr);
            if (index === 3) {
                index = -1;
            }
            $scope.sysData[0].cross[k] = $scope.clr[index + 1];
        }
        $scope.switchColor = function(clr, k, v) {
            var index = $scope.clr.indexOf(clr);
            if (index === 3) {
                index = -1;
            }
            $scope.rowData[k].quality[v] = $scope.clr[index + 1];
        }
        $scope.switchTruck = function(clr, k, v, s) {
            var index = $scope.clr.indexOf(clr);
            if (index === 3) {
                index = -1;
            }
            $scope.rowData[k][s].truck[v] = $scope.clr[index + 1];
        }
        $scope.switchQ = function(clr, k, v, s) {
            var index = $scope.clr.indexOf(clr);
            if (index === 3) {
                index = -1;
            }
            $scope.rowData[k][s].pie[v] = $scope.clr[index + 1];
        }
        $scope.drawCharts = function() {
            console.log(angular.element(document.getElementById('myCanvass')).getContext("2d"))
            var c = document.getElementById("myCanvass");
            console.log(c)
            var ctx = c.getContext("2d");
            ctx.moveTo(0, 45);
            ctx.lineTo(10, 10);
            ctx.lineTo(20, 15);
            ctx.lineTo(30, 5);
            ctx.lineTo(40, 35);
            ctx.strokeStyle = '#ff0000';
            ctx.stroke();
        }
        $scope.fileChanged = function(files) {
            console.log(files)
            $scope.sheets = [];
            $scope.excelFile = files[0];
            XLSXReaderService.readFile($scope.excelFile, $scope.showPreview).then(function(xlsxData) {
                $scope.sheets = xlsxData.sheets;
                console.log($scope.sheets)
            });
        };

        $scope.saveData = function() {
            $scope.showcontainer = false;
            //$http.post('https://aviation-scd-srvc.run.aws-usw02-pr.ice.predix.io/'+$state.current.name+'/values', $scope.sysData[0])
            $http.post('https://supplychainlocal.run.aws-usw02-pr.ice.predix.io/' + $state.current.name + '/values', $scope.sysData[0])
                .then(
                    function(response) {
                        console.log(response.data);
                        $scope.showcontainer = true;
                    },
                    function(errResponse) {
                        console.error('Error while creating System');
                    }
                );
        }
    }]);
});

define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('ReportPageCtrl', ['$scope', '$log', function ($scope, $log) {



    }]);
});

import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'auctionDonationForm',
  templateUrl: `auctionDonationForm.component.html`,
  styleUrls:['../stylesheets/auctionDonationForm.css'],
})
export class AuctionDonationFormComponent  { }

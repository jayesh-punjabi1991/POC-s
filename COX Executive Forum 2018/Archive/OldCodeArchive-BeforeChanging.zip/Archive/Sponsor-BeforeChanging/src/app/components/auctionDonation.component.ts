import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'auctionDonation',
  templateUrl: `auctionDonation.component.html`,
  styleUrls:['../stylesheets/auctionDonation.css'],
})
export class AuctionDonationComponent  { }

import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'print',
  templateUrl: `print.component.html`,
  styleUrls:['../stylesheets/print.css'],
})
export class PrintComponent  { }

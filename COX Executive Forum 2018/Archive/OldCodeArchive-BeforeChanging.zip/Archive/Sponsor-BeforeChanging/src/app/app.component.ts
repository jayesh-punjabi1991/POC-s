import { Component } from '@angular/core';

@Component({
  selector: 'cox-forum',
  template: `
      <router-outlet></router-outlet>
  `,
})
export class AppComponent  {  }

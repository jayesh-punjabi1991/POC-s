import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'topHeader',
  templateUrl: `header.component.html`,
  styleUrls:['../stylesheets/topHeader.css'],
})
export class HeaderComponent  { }

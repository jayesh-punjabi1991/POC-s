import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'bottomfooter',
  templateUrl: `./footer.component.html`,
  styleUrls:['../stylesheets/bottomfooter.css'],
})
export class FooterComponent  { }
